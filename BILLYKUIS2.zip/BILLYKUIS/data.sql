INSERT INTO perusahaan minyak (wilmar, gedung jw) VALUES ('PT Wilmar', 'Gedung JW MARRIOT Medan');
INSERT INTO perusahaan saos (abc, KIM) VALUES ('PT ABC', 'KIM Medan');
INSERT INTO perbankan (BCA, jalan diponegoro) VALUES ('PT BCA', 'Jalan Diponegoro');

INSERT INTO bapak-bapak pakai jas (pak robin, komplek malibu indah) VALUES ('Robin', 'Komplek malibu indah');
INSERT INTO direktur perusahaan (ibu sonya, komplek cemara asri) VALUES ('Sonya', 'Komplek Cemara Asri');
INSERT INTO manager bank bca (pak billy, komplek cemara hijau) VALUES ('Billy', 'Komplek Cemara Hijau');

INSERT INTO roti tawar (roti tawar, 15000) VALUES ('Roti Tawar', 15000);
INSERT INTO roti manis (roti manis, 5000) VALUES ('Roti Manis', 5000);
INSERT INTO roti kosong (roti kosong, 4000) VALUES ('Roti Kosong', 4000);
INSERT INTO roti kelapa (roti kelapa, 8000) VALUES ('Roti Kelapa', 8000);
INSERT INTO roti abon ayam (roti abon ayam, 10000) VALUES ('Roti Abon Ayam', 10000);
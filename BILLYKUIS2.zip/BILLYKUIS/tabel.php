<?php
$host = "localhost";
$user = "username";
$pass = "password";
$db = "roti_aneka_rasa";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi Gagal: " . $conn->connect_error);
}

$query_perusahaan = "SELECT * FROM informasi_perusahaan";
$result_perusahaan = $conn->query($query_perusahaan);
$perusahaan = $result_perusahaan->fetch_assoc();

$query_pelanggan = "SELECT * FROM informasi_pelanggan";
$result_pelanggan = $conn->query($query_pelanggan);
$pelanggan = $result_pelanggan->fetch_assoc();

$query_produk = "SELECT * FROM daftar_produk";
$result_produk = $conn->query($query_produk);

echo "<h1>Invoice Pembelian Barang</h1>";
echo "<h2>PT Roti Aneka Rasa Indonesia</h2>";
echo "<p>Informasi Perusahaan:</p>";
echo "<p>Nama Perusahaan: " . $perusahaan['nama_perusahaan'] . "</p>";
echo "<p>Alamat Perusahaan: " . $perusahaan['alamat_perusahaan'] . "</p>";
echo "<p>Informasi Pelanggan:</p>";
echo "<p>Nama Pelanggan: " . $pelanggan['nama_pelanggan'] . "</p>";
echo "<p>Alamat Pelanggan: " . $pelanggan['alamat_pelanggan'] . "</p>";
echo "<p>Daftar Produk:</p>";

echo "<table border='1'>";
echo "<tr><th>ID</th><th>Nama Produk</th><th>Harga</th></tr>";
while ($row = $result_produk->fetch_assoc()) {
    echo "<tr><td>" . $row['id'] . "</td><td>" . $row['nama_produk'] . "</td><td>" . $row['harga'] . "</td></tr>";
}
echo "</table>";

$conn->close();
?>

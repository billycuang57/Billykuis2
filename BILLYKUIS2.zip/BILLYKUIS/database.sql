CREATE DATABASE IF NOT EXISTS roti_aneka_rasa;
USE roti_aneka_rasa;

CREATE TABLE IF NOT EXISTS informasi_perusahaan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_perusahaan VARCHAR(255) NOT NULL,
    alamat_perusahaan TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS informasi_pelanggan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_pelanggan VARCHAR(255) NOT NULL,
    alamat_pelanggan TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS daftar_produk (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_produk VARCHAR(255) NOT NULL,
    harga DECIMAL(10, 2) NOT NULL
);
